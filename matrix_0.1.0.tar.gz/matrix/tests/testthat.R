library(testthat)
library(matrix)

test_check("matrix")
